@echo off
setlocal
cd /d "%~dp0"
title ALL-IN-ONE-AI HTML Launcher v1.3

echo ================================================================
echo ALL-IN-ONE-AI HTML Launcher v1.3
echo ================================================================
echo.
echo The browser will open automatically at:
echo http://127.0.0.1:8765
echo.
echo Keep this window open while using the HTML interface.
echo Press CTRL+C to stop the server.
echo.

start "" cmd /c "timeout /t 2 /nobreak >nul & start "" http://127.0.0.1:8765"
python web_launcher\app.py

echo.
pause
