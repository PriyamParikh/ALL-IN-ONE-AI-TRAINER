@echo off
setlocal
cd /d "%~dp0"
title ALL-IN-ONE-AI Python GUI
python all_in_one_ai_5in1_launcher.py
if errorlevel 1 (
    echo.
    echo ALL-IN-ONE-AI stopped with an error.
    pause
)
