@echo off
setlocal
cd /d "%~dp0"
title ALL-IN-ONE-AI Installation

echo ============================================================
echo              ALL-IN-ONE-AI - INSTALLATION
echo ============================================================
echo.
python --version
if errorlevel 1 (
    echo Python was not found.
    echo Install 64-bit Python 3.11 and run this file again.
    pause
    exit /b 1
)

echo.
echo Updating pip...
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :failed

echo.
echo Installing ALL-IN-ONE-AI requirements...
python -m pip install --no-cache-dir -r requirements_all_in_one_ai.txt
if errorlevel 1 goto :failed

echo.
echo Checking installed packages...
python -m pip check

echo.
echo ============================================================
echo Installation completed.
echo Next run: 02_VERIFY_ALL_IN_ONE_AI.bat
echo ============================================================
pause
exit /b 0

:failed
echo.
echo Installation failed. Read the error shown above.
pause
exit /b 1
