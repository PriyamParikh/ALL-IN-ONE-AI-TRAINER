"""Shared camera management for ALL-IN-ONE-AI.

Important Windows rule:
The camera scanner, preview window, Image AI, Object AI and Pose AI must all
open the selected index through the SAME OpenCV backend. Otherwise index 0
may refer to different physical cameras.

Version 1.5 therefore uses DirectShow consistently on Windows and does NOT
silently fall back to another backend. A failed/busy selected camera raises an
error instead of accidentally opening a different physical device.
"""
from __future__ import annotations

import os
from typing import Optional

import cv2

CAMERA_ENV = "ALL_IN_ONE_AI_CAMERA_INDEX"
CAMERA_BACKEND_ENV = "ALL_IN_ONE_AI_CAMERA_BACKEND"

WINDOWS_BACKEND_NAME = "DSHOW"


def default_camera_index() -> int:
    try:
        return max(0, int(os.environ.get(CAMERA_ENV, "0")))
    except Exception:
        return 0


def default_camera_backend() -> str:
    if os.name == "nt":
        return os.environ.get(CAMERA_BACKEND_ENV, WINDOWS_BACKEND_NAME).upper()
    return "DEFAULT"


def _backend_code(name: str):
    name = (name or "").upper().strip()
    if os.name != "nt":
        return None
    if name == "DSHOW":
        return cv2.CAP_DSHOW
    if name == "MSMF":
        return cv2.CAP_MSMF
    return None


def open_camera(
    index: int,
    width: Optional[int] = None,
    height: Optional[int] = None,
    backend: Optional[str] = None,
):
    """Open exactly the requested camera index using one consistent backend.

    On Windows the default is DirectShow. There is deliberately NO fallback to
    cv2.VideoCapture(index), because a fallback can remap the same numeric index
    to a different physical camera.
    """
    index = int(index)
    backend_name = (backend or default_camera_backend()).upper()
    code = _backend_code(backend_name)

    if code is None:
        cap = cv2.VideoCapture(index)
    else:
        cap = cv2.VideoCapture(index, code)

    if width:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(width))
    if height:
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(height))

    return cap


def camera_backend_name(cap) -> str:
    try:
        name = cap.getBackendName()
        return str(name)
    except Exception:
        return default_camera_backend()


def scan_camera_indices(max_index: int = 10) -> list[int]:
    """Return indices that open successfully through the SAME backend."""
    found: list[int] = []

    for index in range(max(1, int(max_index))):
        cap = open_camera(index)
        try:
            if not cap.isOpened():
                continue

            ok = False
            frame = None
            for _ in range(5):
                ok, frame = cap.read()
                if ok and frame is not None and getattr(frame, "size", 0):
                    break

            if ok:
                found.append(index)
        finally:
            cap.release()

    return found


def probe_camera(index: int) -> dict | None:
    """Return basic information for the selected index using the shared backend."""
    cap = open_camera(index)
    try:
        if not cap.isOpened():
            return None

        ok = False
        frame = None
        for _ in range(5):
            ok, frame = cap.read()
            if ok and frame is not None and getattr(frame, "size", 0):
                break

        if not ok or frame is None:
            return None

        h, w = frame.shape[:2]
        return {
            "index": int(index),
            "width": int(w),
            "height": int(h),
            "backend": camera_backend_name(cap),
        }
    finally:
        cap.release()


def preview_camera(index: int, title: str = "ALL-IN-ONE-AI Camera Preview") -> None:
    """Preview exactly the camera that later modules will open."""
    cap = open_camera(index, 960, 540)

    if not cap.isOpened():
        raise RuntimeError(
            f"Camera index {index} could not be opened with "
            f"{default_camera_backend()}. Close other camera applications and try again."
        )

    backend = camera_backend_name(cap)

    try:
        while True:
            ok, frame = cap.read()
            if not ok or frame is None:
                continue

            cv2.putText(
                frame,
                f"Camera {index} | Backend {backend}",
                (14, 32),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.72,
                (255, 255, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                frame,
                "Q / ESC = close preview",
                (14, 62),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.62,
                (255, 255, 255),
                2,
                cv2.LINE_AA,
            )

            cv2.imshow(title, frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break
    finally:
        cap.release()
        try:
            cv2.destroyWindow(title)
        except Exception:
            cv2.destroyAllWindows()
