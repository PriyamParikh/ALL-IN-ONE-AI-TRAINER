# ALL-IN-ONE-AI COMPLETE v1.3

This folder contains the complete 5-in-1 suite together with the corrected camera-aware HTML launcher.

## Included modules

- Image AI — Single Image Classification
- Object AI — YOLO Multi-Object Detection
- Pose AI — Personalised YOLO Pose Classification
- Audio AI — Microphone Sound Classification
- Data AI — CSV/Excel Machine Learning

## Camera update

The suite supports:

- scanning camera indices 0–9
- manual camera index entry
- camera preview before starting a module
- external USB webcams
- passing the selected camera from the HTML launcher to the vision modules

The HTML camera stream is handled by Flask + Python/OpenCV rather than browser `getUserMedia()`.

## First-time installation

Run:

```text
01_INSTALL_REQUIREMENTS.bat
```

Then:

```text
02_VERIFY_ALL_IN_ONE_AI.bat
```

## Run the standard Python GUI

```text
03_RUN_PYTHON_GUI.bat
```

## Run the HTML/browser launcher

```text
04_RUN_HTML_GUI.bat
```

The browser interface opens at:

```text
http://127.0.0.1:8765
```

Before launching Image AI, Object AI or Pose AI:

1. Scan Cameras
2. Select the camera
3. Use Camera
4. Preview it
5. Stop Preview
6. Verify Modules
7. Open the required module

## Folder structure

```text
ALL_IN_ONE_AI_COMPLETE_v1_3/
├── START_HERE.txt
├── 01_INSTALL_REQUIREMENTS.bat
├── 02_VERIFY_ALL_IN_ONE_AI.bat
├── 03_RUN_PYTHON_GUI.bat
├── 04_RUN_HTML_GUI.bat
├── all_in_one_ai_5in1_launcher.py
├── personalized_image_ai_trainer_gui_v3_manual_hog.py
├── personalized_multi_object_ai_trainer_gui_v3.py
├── personalized_yolo_pose_classifier_gui.py
├── personalized_audio_classifier_gui.py
├── all_in_one_ai_data_trainer_gui.py
├── camera_utils.py
├── verify_all_in_one_ai.py
├── requirements_all_in_one_ai.txt
├── README_ALL_IN_ONE_AI.md
├── STUDENT_QUICK_START.md
├── CAMERA_UPDATE_NOTES.md
└── web_launcher/
    ├── app.py
    └── templates/
        └── index.html
```

## Important note

The browser interface is intentionally a launcher and camera manager. The five ML applications remain Python applications so the original OpenCV, Ultralytics, scikit-learn, audio, model export and local dataset functionality is preserved.
