@echo off
cd /d "%~dp0"
title ALL-IN-ONE-AI Camera Mapping Test
python TEST_CAMERA_MAPPING.py
pause
