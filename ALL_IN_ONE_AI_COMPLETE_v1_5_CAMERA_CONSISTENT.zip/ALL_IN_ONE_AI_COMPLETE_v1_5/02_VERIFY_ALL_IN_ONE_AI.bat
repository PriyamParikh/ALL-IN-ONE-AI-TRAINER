@echo off
setlocal
cd /d "%~dp0"
title ALL-IN-ONE-AI Verification
python verify_all_in_one_ai.py
pause
