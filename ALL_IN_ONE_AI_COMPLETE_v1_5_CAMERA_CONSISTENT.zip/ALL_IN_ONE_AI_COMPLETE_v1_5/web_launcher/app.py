from __future__ import annotations

import os
import sys
import time
import threading
import subprocess
from pathlib import Path

import cv2
from flask import Flask, Response, jsonify, render_template, request

APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from camera_utils import (
    CAMERA_ENV,
    CAMERA_BACKEND_ENV,
    default_camera_backend,
    open_camera,
    probe_camera,
)

app = Flask(__name__, template_folder=str(APP_DIR / "templates"))

selected_camera_index = 0
camera_lock = threading.Lock()

# ---------------------------------------------------------------------
# MODULE DISCOVERY
# ---------------------------------------------------------------------
# The original version used one hard-coded path for each module.
# This version automatically searches the ALL-IN-ONE-AI project tree.

MODULE_CANDIDATES = {
    "image": [
        "personalized_image_ai_trainer_gui_v3_manual_hog.py",
        "personalized_image_ai_trainer_gui_v3.py",
        "personalized_image_ai_trainer.py",
    ],
    "object": [
        "personalized_multi_object_ai_trainer_gui_v3.py",
        "personalized_multi_object_ai_trainer_gui.py",
        "personalized_multi_object_ai_trainer.py",
    ],
    "pose": [
        "personalized_yolo_pose_classifier_gui.py",
        "personalized_yolo_pose_classifier.py",
        "yolo_pose_trainer_gui.py",
    ],
    "audio": [
        "personalized_audio_classifier_gui.py",
        "personalized_audio_classification_gui.py",
        "personalized_audio_classifier.py",
    ],
    "data": [
        "all_in_one_ai_data_trainer_gui.py",
        "all_in_one_ai_data_trainer.py",
        "data_ai_trainer_gui.py",
    ],
}

MODULE_GLOB_HINTS = {
    "image": ["*image*trainer*.py", "*image*classifier*.py"],
    "object": ["*multi*object*trainer*.py", "*object*detector*.py"],
    "pose": ["*pose*classifier*.py", "*pose*trainer*.py"],
    "audio": ["*audio*classifier*.py", "*audio*classification*.py"],
    "data": ["*data*trainer*.py", "*tabular*trainer*.py"],
}


def search_roots():
    """
    Search likely project folders.
    Works whether web_launcher is:
      - directly inside the project
      - inside a patch folder copied into the project
      - launched from the project working directory
    """
    roots = []

    possible = [
        APP_DIR.parent,
        APP_DIR.parent.parent,
        Path.cwd(),
        Path.cwd().parent,
    ]

    # Optional explicit override:
    env_root = os.environ.get("ALL_IN_ONE_AI_ROOT")
    if env_root:
        possible.insert(0, Path(env_root))

    seen = set()
    for p in possible:
        try:
            p = p.resolve()
        except Exception:
            continue
        if p.exists() and p not in seen:
            roots.append(p)
            seen.add(p)

    return roots


def safe_recursive_files(root: Path, filename: str):
    """
    Search recursively, but avoid typical huge/irrelevant folders.
    """
    bad_parts = {
        ".git", "__pycache__", ".venv", "venv",
        "site-packages", "node_modules", "runs", "outputs"
    }

    matches = []
    try:
        for p in root.rglob(filename):
            if any(part in bad_parts for part in p.parts):
                continue
            if p.is_file():
                matches.append(p)
    except Exception:
        pass
    return matches


def resolve_module(module_name: str):
    # 1. Exact candidate filenames
    for root in search_roots():
        for candidate in MODULE_CANDIDATES.get(module_name, []):
            direct = root / candidate
            if direct.exists():
                return direct.resolve()

    # 2. Recursive exact filename search
    for root in search_roots():
        for candidate in MODULE_CANDIDATES.get(module_name, []):
            hits = safe_recursive_files(root, candidate)
            if hits:
                return hits[0].resolve()

    # 3. Fallback glob search for renamed files
    for root in search_roots():
        for pattern in MODULE_GLOB_HINTS.get(module_name, []):
            try:
                hits = []
                for p in root.rglob(pattern):
                    if p.is_file() and "web_launcher" not in p.parts:
                        hits.append(p)
                if hits:
                    # Prefer more specific / shorter paths
                    hits.sort(key=lambda p: (len(p.parts), len(p.name)))
                    return hits[0].resolve()
            except Exception:
                pass

    return None


def module_status():
    result = {}
    for name in MODULE_CANDIDATES:
        path = resolve_module(name)
        result[name] = {
            "found": path is not None,
            "path": str(path) if path else None,
            "candidates": MODULE_CANDIDATES[name],
        }
    return result


# ---------------------------------------------------------------------
# CAMERA
# ---------------------------------------------------------------------



# ---------------------------------------------------------------------
# ROUTES
# ---------------------------------------------------------------------

@app.get("/")
def home():
    return render_template("index.html", selected_camera=selected_camera_index)


@app.get("/favicon.ico")
def favicon():
    return ("", 204)


@app.get("/api/health")
def health():
    return jsonify({
        "ok": True,
        "message": "Flask backend is reachable",
        "search_roots": [str(p) for p in search_roots()]
    })


@app.get("/api/modules")
def modules():
    return jsonify({
        "ok": True,
        "modules": module_status(),
        "search_roots": [str(p) for p in search_roots()]
    })


@app.get("/api/cameras")
def list_cameras():
    found = []

    max_index = int(request.args.get("max", 10))
    max_index = min(max(max_index, 1), 20)

    for index in range(max_index):
        info = probe_camera(index)
        if info is not None:
            found.append(info)

    return jsonify({
        "ok": True,
        "selected": selected_camera_index,
        "cameras": found,
    })


@app.post("/api/camera/select")
def select_camera():
    global selected_camera_index

    data = request.get_json(silent=True) or {}

    try:
        index = int(data.get("index"))
    except Exception:
        return jsonify({
            "ok": False,
            "error": "Camera index must be an integer."
        }), 400

    info = probe_camera(index)

    if info is None:
        return jsonify({
            "ok": False,
            "error": f"Camera {index} could not be opened by OpenCV."
        }), 400

    selected_camera_index = index

    return jsonify({
        "ok": True,
        "camera": info
    })


@app.get("/api/camera/test/<int:index>")
def test_camera(index: int):
    info = probe_camera(index)

    if info is None:
        return jsonify({
            "ok": False,
            "error": f"Camera {index} is unavailable."
        }), 404

    return jsonify({
        "ok": True,
        "camera": info
    })


def mjpeg_stream(index: int):
    cap = open_camera(index)

    if not cap.isOpened():
        cap.release()
        return

    try:
        while True:
            ok, frame = cap.read()

            if not ok or frame is None:
                time.sleep(0.05)
                continue

            ok, encoded = cv2.imencode(
                ".jpg",
                frame,
                [cv2.IMWRITE_JPEG_QUALITY, 82]
            )

            if not ok:
                continue

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n" +
                encoded.tobytes() +
                b"\r\n"
            )

    finally:
        cap.release()


@app.get("/video_feed/<int:index>")
def video_feed(index: int):
    if probe_camera(index) is None:
        return Response(
            f"Camera {index} is unavailable.",
            status=404,
            mimetype="text/plain"
        )

    return Response(
        mjpeg_stream(index),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )


@app.post("/api/launch/<module_name>")
def launch_module(module_name: str):
    module_name = module_name.lower()

    if module_name not in MODULE_CANDIDATES:
        return jsonify({
            "ok": False,
            "error": f"Unknown module: {module_name}"
        }), 404

    script = resolve_module(module_name)

    if script is None:
        return jsonify({
            "ok": False,
            "error": (
                f"{module_name.title()} AI module could not be found. "
                f"Use 'Verify Modules' to see the folders searched."
            ),
            "searched_roots": [str(p) for p in search_roots()],
            "expected_names": MODULE_CANDIDATES[module_name],
        }), 404

    env = os.environ.copy()
    env["ALL_IN_ONE_AI_CAMERA_INDEX"] = str(selected_camera_index)
    env["ALL_IN_ONE_AI_CAMERA_BACKEND"] = default_camera_backend()
    env["ALL_IN_ONE_AI_ROOT"] = str(script.parent)

    try:
        # IMPORTANT:
        # Run the module from ITS OWN folder so relative files, assets,
        # YOLO weights and saved datasets continue to work.
        subprocess.Popen(
            [sys.executable, str(script)],
            cwd=str(script.parent),
            env=env
        )

    except Exception as exc:
        return jsonify({
            "ok": False,
            "error": f"Failed to start {script.name}: {exc}"
        }), 500

    return jsonify({
        "ok": True,
        "module": module_name,
        "script": str(script),
        "camera_index": selected_camera_index
    })


if __name__ == "__main__":
    print("=" * 70)
    print("ALL-IN-ONE-AI HTML Launcher v1.3")
    print("=" * 70)
    print("Searching for Python modules...")
    for name, info in module_status().items():
        print(
            f"{name.upper():7s}: "
            + (info["path"] if info["found"] else "NOT FOUND")
        )
    print("=" * 70)

    app.run(
        host="127.0.0.1",
        port=8765,
        debug=False,
        threaded=True
    )
