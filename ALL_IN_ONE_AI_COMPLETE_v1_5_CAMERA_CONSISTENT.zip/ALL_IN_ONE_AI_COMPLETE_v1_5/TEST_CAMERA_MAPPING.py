from camera_utils import scan_camera_indices, probe_camera, preview_camera, default_camera_backend

print("ALL-IN-ONE-AI Camera Consistency Test")
print("-------------------------------------")
print("Backend:", default_camera_backend())

indices = scan_camera_indices(10)
print("Detected indices:", indices)

for index in indices:
    info = probe_camera(index)
    print(f"Camera {index}: {info}")

if indices:
    print()
    print("Opening each detected camera for visual confirmation.")
    print("Press Q or ESC to close each preview.")
    for index in indices:
        preview_camera(index, f"Consistency Test - Camera {index}")
else:
    input("No cameras detected. Press Enter to exit.")
