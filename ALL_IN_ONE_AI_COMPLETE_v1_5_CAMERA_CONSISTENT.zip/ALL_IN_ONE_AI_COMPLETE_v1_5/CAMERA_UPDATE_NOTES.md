# ALL-IN-ONE-AI v1.1 Camera Update

- Launcher camera scan for indices 0-9.
- Camera dropdown at startup.
- Preview camera before opening a vision module.
- Selected launcher camera is propagated through `ALL_IN_ONE_AI_CAMERA_INDEX`.
- Image AI: camera index and preview in capture and real-time tabs.
- Object AI: camera index and preview for dataset capture; existing real-time camera selector now defaults to launcher selection and has preview.
- Pose AI: capture and live camera selectors default to launcher selection and now include preview buttons.
- Audio AI and Data AI are unchanged because they do not use a camera.
